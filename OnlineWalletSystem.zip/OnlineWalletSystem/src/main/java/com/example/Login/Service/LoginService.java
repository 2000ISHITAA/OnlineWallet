package com.example.Login.Service;

import com.example.Login.Dto.LoginDto;
import com.example.Login.Dto.LoginResponseDto;

public interface LoginService {
	
	
	public LoginResponseDto loginUser(LoginDto loginDto);

}