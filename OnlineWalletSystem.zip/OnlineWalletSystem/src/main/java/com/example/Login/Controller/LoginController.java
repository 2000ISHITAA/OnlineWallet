package com.example.Login.Controller;



import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Login.Dto.LoginDto;
import com.example.Login.Dto.LoginResponseDto;
import com.example.Login.Service.LoginServiceImpl;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/login")

public class LoginController {

	@Autowired
	LoginServiceImpl impl;
	
	private static Logger logger = LogManager.getLogger();

	@PostMapping("/loginUser")
	public ResponseEntity<LoginResponseDto> loginUser(@RequestBody LoginDto login) {
		logger.info("Sending login request of user");
		LoginResponseDto save = impl.loginUser(login);
		logger.info("Logged in sucessfully!");
		return new ResponseEntity<>(save, HttpStatus.OK);
	}
}
