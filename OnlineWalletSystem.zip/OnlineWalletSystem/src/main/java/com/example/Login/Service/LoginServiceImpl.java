package com.example.Login.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;


import com.example.Login.Dto.LoginDto;
import com.example.Login.Dto.LoginResponseDto;
import com.example.Login.Dto.UserDto;
import com.example.Login.Exception.EmailNotFoundException;
import com.example.Login.Exception.InvalidPasswordException;
import com.example.Login.Repository.LoginRepository;

@Service
public class LoginServiceImpl implements LoginService {

	@Autowired
	LoginRepository loginRepository;
	@Autowired
	RestTemplate restTemplate;


	@Override
	public LoginResponseDto loginUser(LoginDto loginDto) {
		LoginResponseDto newLogin = new LoginResponseDto();

		String email = loginDto.getLoginEmail();
		String password = loginDto.getLoginPassword();

		try {
			ResponseEntity<UserDto> responseEntity = restTemplate
					.getForEntity("http://localhost:8090/user/getUserByEmail/" + email, UserDto.class);

			UserDto userDto = responseEntity.getBody();
			newLogin.setEmail(userDto.getEmail());

			if (userDto.getPassword().equals(password)) {
				newLogin.setLoggedIn(true);

			} else {

				throw new InvalidPasswordException("Invalid password");
			}

		} catch (HttpClientErrorException ex) {

			throw new EmailNotFoundException("Invalid email");

		}
		return newLogin;

	}
}
	
	